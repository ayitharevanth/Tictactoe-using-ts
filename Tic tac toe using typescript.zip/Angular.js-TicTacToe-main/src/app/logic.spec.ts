import { Logic } from './logic';

describe('Logic', () => {
  it('should create an instance', () => {
    expect(new Logic()).toBeTruthy();
  });
});
